var isMobile = false;
var progressBarCount = 0;
var sliderAnimation;
var sliderIsAnimating = false;
var windowWidth;
var windowHeight;

$(function(){
    checkMobile();

    $(window).resize(function(){
        checkMobile();

        if(!isMobile) {
            $('#nav-menu').css('display', 'block');
        } else {
            $('#nav-menu').css('display', 'none');
        }

        if($('.slider').length != 0) {
            sliderHeight();
        }
    });

    $('.close-button').click(function(){
        $(this).closest('.modal-container').fadeOut(200);
    });

    $('.mobile-nav').click(function(){
        $('#nav-menu').fadeIn(200);
        $('#nav-menu').height(windowHeight);
    });

    if($('.anchor-link').length !== 0) {
        anchorLinkFunctions();
    }

    if($('.slider').length != 0) {

        $('.slider').each(function(){

            var that = $(this);
            setSliderAnimation(that);
        });
    }
});

$(window).load(function(){

    windowSize();
    $('#hero').height(windowHeight);
    navOpacity();
    verticallyCenter();
    sliderControls();
    sliderHeight();

    $(window).scroll(function(){
        if (!isMobile) {
            navOpacity();
        }
    });

});

function anchorLinkFunctions() {
    $('.anchor-link').click(function(e){
        e.preventDefault();
        var navHeight = $('nav').outerHeight();
        var scrollTarget = $(this).closest('section').next('section').offset().top - navHeight;
        $('body, html').animate({'scrollTop': scrollTarget}, 800);
    });
}

function checkMobile() {
    if($('body').css('position') == 'static') {
        isMobile = true;
    } else {
        isMobile = false;
    }
}

function navOpacity() {
    if($(window).scrollTop() > 0) {
        if(!$('nav').hasClass('opaque')) {
            $('nav').addClass('opaque')
        }
    } else {
        $('nav').removeClass('opaque');
    }
}

function verticallyCenter() {

    $('.vertical-center').each(function(){
        var container_height = $(this).parent().height();
        var this_height = $(this).height();
        var difference = container_height - this_height;

        if ( difference > 0 ) {

            var padding_top = difference / 2;
            $(this).css('padding-top', padding_top + 'px');
        }
    });
}

function windowSize() {
    $('body').css('overflow', 'hidden');
    windowHeight = $(window).height();
    windowWidth = $(window).width();
    $('body').css('overflow', 'scroll');
}



/* --- SLIDERS --- */

function setSliderAnimation(that){
    sliderAnimation = setInterval(function(){
        rotateSlidesNext(that);
    }, 5000);
}

function sliderControls() {

    $('.slider .left-arrow').click(function(){

        if (!sliderIsAnimating) {
            var that = $(this).parent($('.slider'));
            rotateSlidesPrevious(that, 'left');
            clearInterval(sliderAnimation);
            setSliderAnimation(that);
        }
    });

    $('.slider .right-arrow').click(function(){

        if (!sliderIsAnimating) {
            var that = $(this).parent($('.slider'));
            rotateSlidesNext(that, 'right');
            clearInterval(sliderAnimation);
            setSliderAnimation(that);
        }
    }); 
}

function sliderHeight() {
    var image_height = $('.slider .slide img').height();
    $('.slider').height(image_height);
}

function rotateSlides(that, currentSlide, nextSlide) {

    var $currentSlide = currentSlide;
    var $nextSlide = nextSlide;
    sliderIsAnimating = true;
    
    $currentSlide.animate({'opacity': 0}, 700, function() {

        $(currentSlide).css('z-index', 0);
        $(nextSlide).css('z-index', 99);

        $nextSlide.animate({'opacity': 1}, 700, function(){

            $currentSlide.removeClass('current');
            $nextSlide.addClass('current');  
            sliderIsAnimating = false;       
        });
    });
}


function rotateSlidesPrevious(that) {

    var $currentSlide = that.find('.slide.current');
    var $nextSlide = $currentSlide.prev('.slide');

    if ( $nextSlide.length == 0 ) {

        $nextSlide = that.find('.slide').last();
    }

    rotateSlides(that, $currentSlide, $nextSlide);
}

function rotateSlidesNext(that) {

    var $currentSlide = that.find('.slide.current');
    var $nextSlide = $currentSlide.next();

    if ( $nextSlide.length == 0 ) {

        $nextSlide = that.find('.slide').first();
    }

    rotateSlides(that, $currentSlide, $nextSlide);
}